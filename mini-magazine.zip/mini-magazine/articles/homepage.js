
function openNav() {
    document.getElementById("mysidenav").style.width = "250px";
    document.getElementById("main").style.marginLeft = "250px";
}
function closeNav() {
    document.getElementById("mysidenav").style.width = "0";
    document.getElementById("main").style.marginLeft = "0";
}